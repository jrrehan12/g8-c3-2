import turtle

length = 10#Initialize the length variable

while length <= :#Write the condition
    for i in range(10):
        #Write the line for pen color
        #Write the line for moving the turtle forward by passing length as a variable
        turtle.right(89)
        length += 0.5
        #write the break statement to exit this for loop
    #Write the line for pen color
    #Write the line for moving the turtle forward by passing length as a variable
    turtle.right(89)
    length += 0.5
